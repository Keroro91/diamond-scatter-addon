import bpy

class DIAMOND_OT_reload_addon(bpy.types.Operator):
    """Recharge l'addon sans redémarrer Blender"""
    bl_idname = "diamond.reload_addon"
    bl_label = "Reload Addon"
    def execute(self, context):
        bpy.ops.script.reload()  # Recharge tous les scripts actifs
        return {'FINISHED'}

class DIAMOND_PT_main_panel(bpy.types.Panel):
    """Panneau principal de l'addon"""
    bl_label = "Diamond Scatter"
    bl_idname = "DIAMOND_PT_main_panel"
    bl_space_type = 'VIEW_3D'  # ✅ Interface dans le viewport 3D
    bl_region_type = 'UI'  # ✅ Dans la barre latérale "N"
    bl_category = "Diamond Scatter"  # ✅ Nom de l'onglet
    
    layout.operator("diamond.reload_addon", text="Reload Addon", icon='FILE_REFRESH')

    def draw(self, context):
        layout = self.layout
        layout.label(text="Bienvenue dans Diamond Scatter !")

def register():
    bpy.utils.register_class(DIAMOND_PT_main_panel)

def unregister():
    bpy.utils.unregister_class(DIAMOND_PT_main_panel)